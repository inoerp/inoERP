<?php  $show_submit_button = 1 ; ?>
<?php require_once('site_control.inc') ?>
<?php require_once('site_control_template.php') ?>
