<?php  $show_submit_button = 1 ; ?>
<?php require_once('customer.inc') ?>
<?php require_once('customer_template.php') ?>
