<?php include_once("../../../includes/basics/basics.inc"); ?>
<div id="json_delete_detail"> <?php  json_delete('option_detail','option_detail_id'); ?> </div>
<div id="json_delete_line"> <?php  json_delete('option_line','option_line_id'); ?> </div>
