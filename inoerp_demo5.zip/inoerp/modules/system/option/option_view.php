<?php require_once('option.inc') ?>
<?php require_once('option_template.php') ?>