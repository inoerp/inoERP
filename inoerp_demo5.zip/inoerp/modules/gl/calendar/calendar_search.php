<?php include_once("../../../include/basics/basics.inc"); ?>
<?php
 global $db;
// if the 'term' variable is not sent with the request, exit
if ( !isset($_REQUEST['term']) )
	exit;
$calendar = $_REQUEST['term'];
$data = calendar::find_calendar_by_calendar($calendar);
 
// jQuery wants JSON data
echo json_encode($data);
flush();
?>